export class Category {
    uid: number;
    name: string;
    description: string;
  }