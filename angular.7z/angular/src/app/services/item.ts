export class Item {
    uuid: number;
    name: string;
    description: string;
    price: number;
    category: number;
    keyword: string;
  }
  